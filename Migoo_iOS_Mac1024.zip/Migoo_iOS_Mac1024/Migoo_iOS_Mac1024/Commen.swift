//
//  Commen.swift
//  testSCNavTabBar
//
//  Created by 戎军 on 15/1/26.
//  Copyright (c) 2015年 戎军. All rights reserved.
//

import Foundation
class Commen {
    let storyBoard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
    let url:Array<String> = ["http://www.36mg.cn/portal.php?mod=rss&catid=0",//门户
    "http://www.36mg.cn/portal.php?mod=rss&catid=1",//资讯资讯
    "http://www.36mg.cn/portal.php?mod=rss&catid=2",//图文
    "http://www.36mg.cn/portal.php?mod=rss&catid=4",//视频
    "http://www.36mg.cn/forum.php?mod=rss&fid=2&auth=49a7RGyG5mzUpFBlqHRNzagmq0vXyuyZKo%2FKPrwiHi%2FbJEIz5a6mCi730bQ",//论坛store板块
    "http://www.36mg.cn/forum.php?mod=rss&fid=38&auth=0bbccMdnzycF7Tm3aRknrK2QXLInSOUDXqZ7O2YlXK%2FB8VCAhmRAwCamKey3",//论坛Mac板块
    "http://www.36mg.cn/forum.php?mod=rss&fid=39&auth=1412zQigjEq9G69HuR4Xd%2FbROSIpA5YVePhLLOBphagC6JrY4AfYomYM45jg",//论坛iPhone板块
    ]
    
}
