//
//  MigooRSS.swift
//  ParseXML
//
//  Created by 戎军 on 14/12/30.
//  Copyright (c) 2014年 戎军. All rights reserved.
//

import Foundation

class MigooRSS {
    var title: String = ""
    var link: String = ""
    var description: String = ""
    var author: String = ""
    var enclosure: String = ""
    var pubDate: String = ""
}