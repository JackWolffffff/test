//
//  AboutUsViewController.swift
//  testSCNavTabBar
//
//  Created by 戎军 on 15/2/2.
//  Copyright (c) 2015年 戎军. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {
    @IBAction func backward(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
