//
//  PassValue.swift
//  MigooAPP
//
//  Created by 戎军 on 15/2/4.
//  Copyright (c) 2015年 rongjun. All rights reserved.
//

import Foundation
//定义protocol
protocol PassValue {
    func passValue(content:MigooRSS)
}